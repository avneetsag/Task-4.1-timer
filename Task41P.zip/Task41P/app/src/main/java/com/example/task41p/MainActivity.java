package com.example.task41p;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {
Chronometer chronometer;
long pauseoffset = 0;
long saveTime,s,m,second,minutes,elapsedtime;
int seconds = 0;
TextView textView;
EditText editText;
String clock, usernames, timings,newname;
SharedPreferences sharedPreferences1, sharedPreferences2;
boolean running,pause;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sharedPreferences1 = getSharedPreferences("com.example.task41p", MODE_PRIVATE);
        sharedPreferences2 = getSharedPreferences("com.example.task41p", MODE_PRIVATE);
        textView = findViewById(R.id.textView);
        editText = findViewById(R.id.editText);
        chronometer = findViewById(R.id.chronometer);
        
    }
    public void startChronometer(View v)
    {
        if(!running)
        {
            chronometer.setBase(SystemClock.elapsedRealtime() - pauseoffset);
            elapsedtime = SystemClock.elapsedRealtime() - pauseoffset;
            chronometer.start();
            running = true;
        }

    }

    public void pauseChronometer(View v)
    {
        if(running)
        {
            chronometer.stop();
            pauseoffset = SystemClock.elapsedRealtime() - chronometer.getBase();
            running = false;
        }
    }

    public void resetChronometer(View v)
    {
        if(running){
            chronometer.stop();
            saveTime = SystemClock.elapsedRealtime()-chronometer.getBase();
            s = (saveTime/1000) % 60;
            m = (saveTime/1000)/60;
            clock = String.format(Locale.getDefault(),"%02d:%02d",m,s);
            running = false;
        }
        else
        {
            if(!pause)
            {
                second = (pauseoffset/1000) % 60;
                minutes = (pauseoffset/1000)/60;
                clock =  String.format(Locale.getDefault(),"%02d:%02d",minutes,second);
                pause = true;
            }
        }
        chronometer.setBase(SystemClock.elapsedRealtime());
        pauseoffset = 0;
        textView.setText("You spent "+ clock +" on " + editText.getText().toString() + " last time");
        SharedPreferences.Editor editext1 = sharedPreferences1.edit();
        SharedPreferences.Editor editext2 = sharedPreferences2.edit();
        editext1.putString(usernames, editText.getText().toString());
        editext2.putString(timings,clock);
        editext1.apply();
        editext2.apply();
    }

    public void checkSharedPreferences()
    {
        String last_name = sharedPreferences1.getString(usernames,"");
        String previous_seconds = sharedPreferences2.getString(timings,"");
        textView.setText("You spent "+ previous_seconds +" on " + last_name + " last time");
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putLong("timed", pauseoffset);
        outState.putBoolean("processing",running);
        outState.putString("username",editText.getText().toString());
        outState.putLong("timing",elapsedtime);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        pauseoffset = savedInstanceState.getLong("timed");
        running = savedInstanceState.getBoolean("processing");
        elapsedtime = savedInstanceState.getLong("timing");
         newname = savedInstanceState.getString("username");
    View v = null;
    if(running)
    {
        chronometer.setBase(elapsedtime);
        chronometer.start();
    }
    if(!running) {
        chronometer.stop();
        saveTime = SystemClock.elapsedRealtime() - chronometer.getBase();
        second = (saveTime / 1000) % 60;
        minutes = (saveTime / 1000) / 60;
        clock = String.format(Locale.getDefault(), "%02d:%02d", minutes, second);
        running = false;
        }
    }
}